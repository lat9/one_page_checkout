<?php
/**
 * jscript_addr_pulldowns
 *
 * handles pulldown menu dependencies for state/country selection
 *
 * @package page
 * @copyright Copyright 2003-2018 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Scott C Wilson Sat Oct 27 01:31:20 2018 -0400 Modified in v1.5.6 $
 */
?>
<script type="text/javascript"><!--

// (checkout_payment_address) Added for dynamic update of countries and zones
// based on address language format selection
// Gernot Hassenpflug
function update_country(theForm) {
  var NumCountry = theForm.zone_country_id.options.length;
  var NumState = theForm.zone_id.options.length;

  var SelectedLanguage = theForm.addrlanguage_id.options[theForm.addrlanguage_id.selectedIndex].value;
  var SelectedCountry = theForm.zone_country_id.options[theForm.zone_country_id.selectedIndex].value;
  var SelectedZone = theForm.elements["zone_id"].value;

  // initialize country select dropdown entries
  while(NumCountry > 0) {
      NumCountry--;
      theForm.zone_country_id.options[NumCountry] = null;
  }

  // update countries
  <?php echo zen_js_country_list_default('SelectedLanguage', 'SelectedCountry', 'theForm', 'zone_country_id', $selected_country ); ?>

  // if we had a value before reset, set it again
  if (SelectedCountry != "") theForm.zone_country_id.options[theForm.zone_country_id.selectedIndex].value = SelectedCountry;

  // if there is no zone_id field to update, or if it is hidden from display, then exit performing no updates  
  //if (!theForm || !theForm.elements["zone_id"]) return;
  //if (theForm.zone_id.type == "hidden") return;

  // initialize state select dropdown entries  
  while(NumState > 0) {
      NumState--;
      theForm.zone_id.options[NumState] = null;
  }

  // try to update just the zone list
  <?php echo zen_js_country_zone_list_default('SelectedLanguage', 'SelectedCountry', 'theForm', 'zone_country_id', 'zone_id', $selected_country, $zone_id ); ?>
  
  // if we had a value before reset, set it again
  if (SelectedZone != "") theForm.elements["zone_id"].value = SelectedZone;

}

// Added for dynamic update of zones (only)
// based on country and address language format selection
// Gernot Hassenpflug
function update_country_zone(theForm) {
  // if there is no zone_id field to update, or if it is hidden from display, then exit performing no updates
    // checking 2 below:
    //if (!theForm || !theForm.elements["zone_id"]) return;
    //if (theForm.zone_id.type == "hidden") return;

  var NumCountry = theForm.zone_country_id.options.length;
  var NumState = theForm.zone_id.options.length;

  var SelectedLanguage = theForm.addrlanguage_id.options[theForm.addrlanguage_id.selectedIndex].value;
  var SelectedCountry = theForm.zone_country_id.options[theForm.zone_country_id.selectedIndex].value;
  // checking below (was reversed):
  //var SelectedZone = theForm.elements["zone_id"].value;
  var SelectedZone = "";
    
  // initialize state dropdown entries
  while(NumState > 0) {
      NumState--;
      theForm.zone_id.options[NumState] = null;
  }

  // build dynamic list of zones per country
  <?php echo zen_js_country_zone_list_default('SelectedLanguage', 'SelectedCountry', 'theForm', 'zone_country_id', 'zone_id'); ?>

  // if we had a value before reset, set it again
  // check below:
  //if (SelectedZone != "") theForm.elements["zone_id"].value = SelectedZone;

}

function update_zone(theForm) {
  // if there is no zone_id field to update, or if it is hidden from display, then exit performing no updates
  if (!theForm || !theForm.elements["zone_id"]) return;
  if (theForm.zone_id.type == "hidden") return;

  // set initial values
  var SelectedCountry = theForm.zone_country_id.options[theForm.zone_country_id.selectedIndex].value;
  var SelectedZone = theForm.elements["zone_id"].value;

  // reset the array of pulldown options so it can be repopulated
  var NumState = theForm.zone_id.options.length;
  while(NumState > 0) {
    NumState = NumState - 1;
    theForm.zone_id.options[NumState] = null;
  }
  // build dynamic list of countries/zones for pulldown
<?php echo zen_js_zone_list('SelectedCountry', 'theForm', 'zone_id'); ?>

  // if we had a value before reset, set it again
  if (SelectedZone != "") theForm.elements["zone_id"].value = SelectedZone;

}

  function hideStateField(theForm) {
    theForm.state.disabled = true;
    theForm.state.className = 'hiddenField';
    theForm.state.setAttribute('className', 'hiddenField');
    //document.getElementById("stateLabel").className = 'hiddenField';
    //document.getElementById("stateLabel").setAttribute('className', 'hiddenField');
    if (document.getElementById("stateLabel")) {
        document.getElementById("stateLabel").className = 'hiddenField';
        document.getElementById("stateLabel").setAttribute('className', 'hiddenField');
    }
    if (document.getElementById("stText")) {
      document.getElementById("stText").className = 'hiddenField';
      document.getElementById("stText").setAttribute('className', 'hiddenField');
    }
    //document.getElementById("stBreak").className = 'hiddenField';
    //document.getElementById("stBreak").setAttribute('className', 'hiddenField');
    if (document.getElementById("stBreak")) {
        document.getElementById("stBreak").className = 'hiddenField';
        document.getElementById("stBreak").setAttribute('className', 'hiddenField');
    }
  }

  function showStateField(theForm) {
    theForm.state.disabled = false;
    theForm.state.className = 'inputLabel visibleField';
    theForm.state.setAttribute('className', 'visibleField');
    //document.getElementById("stateLabel").className = 'inputLabel visibleField';
    //document.getElementById("stateLabel").setAttribute('className', 'inputLabel visibleField');
    //document.getElementById("stText").className = 'alert visibleField';
    //document.getElementById("stText").setAttribute('className', 'alert visibleField');
    //document.getElementById("stBreak").className = 'clearBoth visibleField';
    //document.getElementById("stBreak").setAttribute('className', 'clearBoth visibleField');
    if (document.getElementById("stateLabel")) {
        document.getElementById("stateLabel").className = 'inputLabel visibleField';
        document.getElementById("stateLabel").setAttribute('className', 'inputLabel visibleField');
    }
    if (document.getElementById("stText")) {
        document.getElementById("stText").className = 'alert visibleField';
        document.getElementById("stText").setAttribute('className', 'alert visibleField');
    }
    if (document.getElementById("stBreak")) {
        document.getElementById("stBreak").className = 'clearBoth visibleField';
        document.getElementById("stBreak").setAttribute('className', 'clearBoth visibleField');
    }
  }
//--></script>
